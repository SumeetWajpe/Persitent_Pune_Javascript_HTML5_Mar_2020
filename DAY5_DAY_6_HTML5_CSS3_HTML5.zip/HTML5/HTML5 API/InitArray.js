onmessage = function (dataFromMainThread) {
// console.log(new XMLHttpRequest())
// console.log(document); // error !
    console.log('Message from Main Thread: ' + dataFromMainThread);
    var largeArray = [];
    for (let i = 0; i < 5000; i++) {
        largeArray[i] = [];
        for (let j = 0; j < 5000; j++) {
            largeArray[i][j] = Math.random();
        }
    }
    postMessage(largeArray[1000][2000]);// send data to script
}