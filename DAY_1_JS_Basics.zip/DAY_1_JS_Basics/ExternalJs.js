function Square(x){
    return x * x;
}
console.log('Addition : ' + Add(20,50));