<?php

echo "Welcome ".$_POST["uname"]

?>